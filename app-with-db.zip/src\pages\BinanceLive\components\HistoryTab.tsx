import { useState } from 'react';
import { SummaryStat } from './StatWidgets';

// ─── History Tab ──────────────────────────────────────────────────────────────

interface Props {
  tradeHistory: any[];
  fetchingHistory: boolean;
  fetchHistory: () => void;
}

export default function HistoryTab({ tradeHistory, fetchingHistory, fetchHistory }: Props) {
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const filtered = selectedDate === 'all'
    ? tradeHistory
    : tradeHistory.filter((t: any) => {
        if (!t.exitTime) return false;
        const d = new Date(t.exitTime);
        if (isNaN(d.getTime())) return false;
        return d.toISOString().split('T')[0] === selectedDate;
      });

  const totalPnL = filtered.reduce((sum: number, t: any) => {
    const v = t.pnl !== undefined ? parseFloat(t.pnl) : 0;
    return sum + (isNaN(v) ? 0 : v);
  }, 0);
  const wins = filtered.filter((t: any) => parseFloat(t.pnl || 0) > 0).length;
  const losses = filtered.filter((t: any) => parseFloat(t.pnl || 0) < 0).length;
  const winRate = filtered.length > 0 ? (wins / filtered.length * 100).toFixed(1) : '0';

  return (
    <div className="glass-panel" style={{ padding: '1.5rem', flex: 1, overflowY: 'auto', borderLeft: '4px solid #faad14', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.2rem' }}>
          <h2 style={{ margin: 0, fontSize: '1.4rem', fontWeight: '800', letterSpacing: '-0.5px', color: '#fff' }}>Archives 📜</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', padding: '0.3rem 0.8rem', background: 'rgba(255,255,255,0.03)', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.08)' }}>
            <span style={{ fontSize: '0.65rem', color: '#888', fontWeight: 'bold', textTransform: 'uppercase' }}>Filter Date:</span>
            <input
              type="date"
              value={selectedDate !== 'all' ? selectedDate : ''}
              onChange={(e) => setSelectedDate(e.target.value || 'all')}
              style={{ background: 'transparent', color: '#faad14', border: 'none', fontSize: '0.8rem', outline: 'none', cursor: 'pointer', fontWeight: 'bold', colorScheme: 'dark' }}
            />
            {selectedDate !== 'all' && (
              <button onClick={() => setSelectedDate('all')} style={{ background: 'rgba(255,255,255,0.1)', border: 'none', color: '#fff', fontSize: '0.65rem', width: '18px', height: '18px', borderRadius: '50%', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
            )}
          </div>
        </div>
        <button onClick={fetchHistory} disabled={fetchingHistory} style={{ background: 'linear-gradient(135deg, rgba(250,173,20,0.2), rgba(250,173,20,0.05))', border: '1px solid rgba(250,173,20,0.3)', color: '#faad14', padding: '0.5rem 1rem', borderRadius: '6px', cursor: 'pointer', fontSize: '0.8rem', fontWeight: 'bold' }}>
          {fetchingHistory ? 'Syncing...' : '🔄 Sync History'}
        </button>
      </div>

      {/* Summary Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1.2rem' }}>
        <SummaryStat icon="📊" label="Total Trades" value={filtered.length} sub={`${wins}W - ${losses}L`} />
        <SummaryStat icon="💰" label="Net Profit" value={`$${totalPnL.toFixed(2)}`} color={totalPnL >= 0 ? '#0ecb81' : '#f6465d'} sub={totalPnL >= 0 ? 'Profitable Session' : 'Loss Session'} />
        <SummaryStat icon="🎯" label="Avg Win Rate" value={`${winRate}%`} color="#faad14" sub="Accuracy Score" />
        <SummaryStat icon="⏱️" label="Date Context" value={selectedDate === 'all' ? 'Historical' : selectedDate} sub="Analysis Range" />
      </div>

      {/* Trade List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '6rem 2rem', color: '#555', border: '1px dashed var(--border-color)', borderRadius: '12px' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1.25rem' }}>📭</div>
            <div style={{ fontSize: '1rem', fontWeight: 'bold', color: '#888' }}>No trades recorded in history.</div>
          </div>
        ) : (
          filtered.map((t: any, i: number) => {
            const pnlVal = t.pnl !== undefined ? parseFloat(t.pnl) : 0;
            return (
              <div key={i} className="glass-panel" style={{ padding: '1.25rem', background: 'rgba(255,255,255,0.02)', borderLeft: `5px solid ${pnlVal >= 0 ? '#0ecb81' : '#f6465d'}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.8rem' }}>
                    <span style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>{t.symbol}</span>
                    <span style={{ background: t.type === 'LONG' ? 'rgba(14,203,129,0.1)' : 'rgba(246,70,93,0.1)', color: t.type === 'LONG' ? '#0ecb81' : '#f6465d', padding: '1px 8px', borderRadius: '4px', fontSize: '0.65rem', fontWeight: 'bold' }}>{t.type}</span>
                    <span style={{ color: '#888', fontSize: '0.75rem' }}>{t.strategy}</span>
                  </div>
                  <span style={{ color: pnlVal >= 0 ? '#0ecb81' : '#f6465d', fontWeight: 'bold', fontSize: '1.1rem' }}>{pnlVal >= 0 ? '+' : ''}{pnlVal.toFixed(2)} USDT</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', fontSize: '0.8rem', color: 'var(--text-muted)', background: 'rgba(0,0,0,0.1)', padding: '0.75rem', borderRadius: '6px' }}>
                  <div>Entry: <span style={{ color: '#eee' }}>${parseFloat(t.entryPrice).toFixed(4)}</span></div>
                  <div>Exit: <span style={{ color: '#eee' }}>${parseFloat(t.exitPrice).toFixed(4)}</span></div>
                  <div>Reason: <span style={{ color: '#faad14' }}>{t.reason || 'Closed'}</span></div>
                  <div style={{ textAlign: 'right' }}>Time: <span style={{ color: '#888' }}>{new Date(t.exitTime).toLocaleString('th-TH', { timeZone: 'Asia/Bangkok' })}</span></div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
